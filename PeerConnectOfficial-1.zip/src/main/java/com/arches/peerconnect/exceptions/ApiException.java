package com.arches.peerconnect.exceptions;


import com.arches.peerconnect.entities.enums.ErrorCode;


/**
 * @author Anurag Mishra, 2018-12-25
 */
public class ApiException extends RuntimeException {

    private ErrorCode errorCode;

    public ApiException(ErrorCode code) {
        super(code.getFullMessage());

        errorCode = code;
    }

    public ErrorCode getErrorCode() {
        return errorCode;
    }
}

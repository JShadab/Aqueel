package com.arches.peerconnect.controllers;


import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.exceptions.ApiException;
import com.arches.peerconnect.models.response.ApiResponse;

import lombok.extern.slf4j.Slf4j;

import org.springframework.dao.InvalidDataAccessApiUsageException;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationCredentialsNotFoundException;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingServletRequestParameterException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

import javax.servlet.http.HttpServletRequest;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Slf4j
@ControllerAdvice
public class ApiExceptionHandler {

    @ExceptionHandler(ApiException.class)
    public ResponseEntity<?> handleApiException(HttpServletRequest request, ApiException ex) {

        var errCode = ex.getErrorCode();

        log.error("API ERROR :: " + errCode.getFullMessage());

        return ResponseEntity
                    .status(errCode.getStatusCode())
                    .body(ApiResponse.from(errCode));
    }

    @ExceptionHandler(Throwable.class)
    public ResponseEntity<?> handleThrowable(HttpServletRequest request, Throwable t) {

        String errMsg;
        ErrorCode code;

        if (t instanceof AuthenticationCredentialsNotFoundException) {

            errMsg = "AUTH CREDENTIALS MISSING ERROR";
            code = ErrorCode.E401;

        } else if (t instanceof InvalidDataAccessApiUsageException) {

            errMsg = "BAD PARAMETER ERROR";
            code = ErrorCode.E011;

        } else if (t instanceof MethodArgumentNotValidException ||
                   t instanceof MissingServletRequestParameterException) {

            errMsg = "VALIDATION ERROR";
            code = ErrorCode.E012;

        } else {

            errMsg = "UNEXPECTED ERROR";
            code = ErrorCode.E500;

        }


        log.error(errMsg, t);

        return ResponseEntity
                    .status(code.getStatusCode())
                    .body(ApiResponse.from(code));
    }


}

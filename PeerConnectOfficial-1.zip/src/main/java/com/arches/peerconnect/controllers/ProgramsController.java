package com.arches.peerconnect.controllers;


import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.peerconnect.Program;
import com.arches.peerconnect.models.request.ProgramRequest;
import com.arches.peerconnect.models.response.ApiResponse;
import com.arches.peerconnect.services.ProgramsService;

import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import javax.validation.Valid;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-26
 */
@RestController
@RequestMapping("/programs")
@PreAuthorize("hasRole('ADMIN')")
public class ProgramsController {

    private final ProgramsService service;

    public ProgramsController(ProgramsService service) {
        this.service = service;
    }

    //

    @GetMapping("")
    public ResponseEntity<?> get(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam(value = "id", required = false) UUID programId) {

        return ResponseEntity.ok(
            programId != null
                ? service.getByCampaignId(tenantId, programId)
                : service.getAllByCampaignId(tenantId)
        );

    }

    @PostMapping("")
    public ResponseEntity<?> create(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @Valid @RequestBody ProgramRequest request) {

        var result = service.create(tenantId, request);
        var location = ServletUriComponentsBuilder
                            .fromCurrentContextPath()
                            .queryParam("id", result.getId())
                            .build()
                            .toUri();

        return ResponseEntity
                    .created(location)
                    .body(ApiResponse.from(ErrorCode.S200));
    }

    @PutMapping("")
    public ResponseEntity<?> create(
        @RequestHeader("Tenant-ID") UUID tenantId,
        @RequestParam("id") UUID programId,
        @Valid @RequestBody ProgramRequest request) {

        service.update(tenantId, programId, request);

        return ResponseEntity.ok(ApiResponse.from(ErrorCode.S200));
    }

}

package com.arches.peerconnect.repos;


import com.arches.peerconnect.entities.peerconnect.Program;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-26
 */
public interface ProgramsRepository extends JpaRepository<Program, UUID> {

    List<Program> getAllByCampaign_Id(UUID campaignId);

    Optional<Program> getByCampaign_IdAndId(UUID campaignId, UUID id);

}

package com.arches.peerconnect.entities;


import com.arches.peerconnect.entities.base.QuestionOption;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.Entity;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.Table;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "DefaultQuestionOptions")
public class DefaultQuestionOption extends QuestionOption {

    @ManyToOne
    @JoinColumn(name = "questionId")
    private DefaultQuestion question;

}

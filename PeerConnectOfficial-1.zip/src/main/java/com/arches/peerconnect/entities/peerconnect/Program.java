package com.arches.peerconnect.entities.peerconnect;


import com.arches.peerconnect.entities.Parent;
import com.arches.peerconnect.entities.base.Auditable;
import com.arches.peerconnect.models.request.ProgramRequest;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

import java.util.Date;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "PC_Programs")
public class Program extends Auditable {

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
    private Date startDate;

    @Column(nullable = false)
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
    private Date endDate;

    @Column(nullable = false)
    private Integer sessionDuration;

    @Column(nullable = false)
    private Integer maxCaptainSessions;

    @Column(nullable = false)
    private Integer maxParticipantSessions;

    @Column(nullable = false)
    private String supportEmail;

    @Column(nullable = false)
    private Boolean isActive = true;


    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "campaignId")
    @JsonIgnore
    private Parent campaign;

    //

    @JsonProperty("campaignId")
    public UUID getCampaignId() {
        return campaign.getId();
    }

    public void updateFromRequest(ProgramRequest request) {
        setName(request.getName());
        setStartDate(request.getStartUtc());
        setEndDate(request.getEndUtc());
        setSessionDuration(request.getAppointmentDuration());
        setMaxCaptainSessions(request.getMaxCaptainAppts());
        setMaxParticipantSessions(request.getMaxParticipantAppts());
        setSupportEmail(request.getSupportEmail());
        setIsActive(request.getIsActive());
    }

    public static Program fromRequest(ProgramRequest request) {
        var program = new Program();
        program.updateFromRequest(request);

        return program;
    }

}

package com.arches.peerconnect.entities;


import com.arches.peerconnect.entities.base.Auditable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "SurveyResponses")
public class SurveyResponse extends Auditable {

    @Column(columnDefinition = "nvarchar", nullable = false)
    private String response;


    @ManyToOne
    @JoinColumn(name = "userId")
    @JsonIgnore
    private Enrollment user;

    @ManyToOne
    @JoinColumn(name = "surveyId")
    @JsonIgnore
    private Survey survey;

    //

    @JsonProperty("userId")
    public UUID getUserId() {
        return user.getId();
    }

    @JsonProperty("surveyId")
    public UUID getSurveyId() {
        return survey.getId();
    }

}

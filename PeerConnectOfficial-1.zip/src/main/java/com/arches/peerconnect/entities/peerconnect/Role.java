package com.arches.peerconnect.entities.peerconnect;


import com.arches.peerconnect.entities.Parent;
import com.arches.peerconnect.entities.base.Auditable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "PC_Roles")
public class Role extends Auditable {

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private Boolean isActive = true;


    @ManyToOne
    @JoinColumn(name = "campaignId")
    @JsonIgnore
    private Parent campaign;

    //

    @JsonProperty("campaignId")
    public UUID getCampaignId() {
        return campaign.getId();
    }

}

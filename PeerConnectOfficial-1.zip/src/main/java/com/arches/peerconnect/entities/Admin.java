package com.arches.peerconnect.entities;


import com.arches.peerconnect.entities.base.Auditable;

import com.fasterxml.jackson.annotation.JsonIgnore;

import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;

import java.util.List;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "Admins")
public class Admin extends Auditable {

    @Column(nullable = false)
    private String firstName;

    @Column(nullable = false)
    private String lastName;

    @Column(nullable = false)
    private String email;

    @Column(nullable = false)
    private String password;

    @Column(nullable = false)
    private Boolean isActive = false;


    @ManyToOne(optional = false)
    @JoinColumn(name = "parentId")
    @JsonIgnore
    private Parent parent;

    @ManyToMany
    @JoinTable(
        name = "AdminRoles",
        joinColumns = @JoinColumn(name = "adminId", referencedColumnName = "id"),
        inverseJoinColumns = @JoinColumn(name = "roleId", referencedColumnName = "id")
    )
    @JsonIgnore
    private List<Role> roles;

}

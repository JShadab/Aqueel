package com.arches.peerconnect.entities.peerconnect;


import org.hibernate.annotations.Type;

import org.springframework.data.annotation.Immutable;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

import java.util.Arrays;
import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Entity
@Immutable
@Table(name = "PC_Captains")
public class Captain {

    @Id
    @Type(type = "uuid-char")
    @Column(columnDefinition = "uniqueidentifier")
    private UUID id;

    @Column(columnDefinition = "nvarchar")
    private String firstName;

    @Column(columnDefinition = "nvarchar")
    private String lastName;

    @Column(columnDefinition = "nvarchar")
    private String title;

    @Column(columnDefinition = "nvarchar")
    private String emailAddress;

    @Column(columnDefinition = "nvarchar")
    private String password;

    @Column(columnDefinition = "nvarchar")
    private String mobileNumber;

    @Column(columnDefinition = "nvarchar")
    private String addressLine1;

    @Column(columnDefinition = "nvarchar")
    private String addressLine2;

    @Column(columnDefinition = "nvarchar")
    private String city;

    @Column(columnDefinition = "nvarchar")
    private String state;

    @Column(columnDefinition = "nvarchar")
    private String zipCode;

    @Column(columnDefinition = "nvarchar")
    private String profileImageUrl;

    @Column(columnDefinition = "nvarchar")
    private String biography;

    @Column(columnDefinition = "nvarchar")
    private String optIn;

    @Column(columnDefinition = "nvarchar")
    private String terms;

    @Column(columnDefinition = "nvarchar")
    private String mediaSourceId;

    @Column(columnDefinition = "nvarchar")
    private String affiliationId;

    @Column(columnDefinition = "nvarchar")
    private String roleId;

    @Column(columnDefinition = "nvarchar")
    private String segmentId;

    @Column(columnDefinition = "nvarchar")
    private String specialityId;

    @Column(columnDefinition = "nvarchar")
    private String topicIdsList;


    private List<String> getTopicIds() {
        return Arrays.asList(topicIdsList.split(","));
    }

}

package com.arches.peerconnect.entities.enums;

/**
 * @author Anurag Mishra, 2018-12-24
 */
public enum Level {

    Tenant,
    Client,
    Brand,
    Campaign

}

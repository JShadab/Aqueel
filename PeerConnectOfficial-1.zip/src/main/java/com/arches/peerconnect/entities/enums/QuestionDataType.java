package com.arches.peerconnect.entities.enums;

/**
 * @author Anurag Mishra, 2018-12-24
 */
public enum QuestionDataType {

    // text
    text,
    password,
    hidden,

    date,
    datetime,
    email,
    number,
    tel,
    time,
    url,


    // checkbox, select
    single,
    singleOther,
    multiple,
    multipleOther

}

package com.arches.peerconnect.entities;


import com.arches.peerconnect.entities.base.Auditable;
import com.arches.peerconnect.entities.enums.Level;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;

import lombok.Data;
import lombok.EqualsAndHashCode;

import org.hibernate.annotations.GenericGenerator;
import org.hibernate.annotations.Type;

import javax.persistence.*;

import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Data
@EqualsAndHashCode(callSuper = false)
@Entity
@Table(name = "Parents")
public class Parent extends Auditable {

    @Id
    @Type(type = "uuid-char")
    @Column(columnDefinition = "uniqueidentifier", nullable = false)
    @GenericGenerator(name = "guid-generator", strategy = "uuid2")
    @GeneratedValue(generator = "guid-generator")
    private UUID id;

    @Column(nullable = false)
    private String name;

    @Column(nullable = false)
    private Level level;

    @Column(nullable = false)
    private Boolean isActive = false;


    @ManyToOne
    @JoinColumn(name = "parentId")
    @JsonIgnore
    private Parent parent;

    @OneToMany(mappedBy = "parent")
    @JsonIgnore
    private List<Parent> children;

    @OneToMany(mappedBy = "parent")
    @JsonIgnore
    private List<Admin> admins;

    //

    @JsonProperty("parentId")
    public UUID getParentId() {
        return parent.getId();
    }

}

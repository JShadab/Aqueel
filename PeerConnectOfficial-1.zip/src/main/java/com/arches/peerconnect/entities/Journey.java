package com.arches.peerconnect.entities;


import com.arches.peerconnect.entities.base.Auditable;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.EqualsAndHashCode;

import javax.persistence.*;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Data
@EqualsAndHashCode(callSuper = true)
@Entity
@Table(name = "Journeys")
public class Journey extends Auditable {

    @Column(nullable = false)
    private String name;

    private String description;

    @Column(nullable = false)
    private Boolean isActive = true;


    @ManyToOne
    @JoinColumn(name = "segmentId")
    @JsonIgnore
    private Segment segment;

    //

    @JsonProperty("segmentId")
    public UUID getSegmentId() {
        return segment.getId();
    }

}

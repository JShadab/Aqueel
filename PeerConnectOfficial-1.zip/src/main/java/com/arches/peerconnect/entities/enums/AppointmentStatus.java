package com.arches.peerconnect.entities.enums;

/**
 * @author Anurag Mishra, 2018-12-24
 */
public enum AppointmentStatus {

    Pending,
    Completed,
    CancelledByCaptain,
    CancelledByPatient

}

package com.arches.peerconnect.utils;

/**
 * @author Anurag Mishra, 2018-12-24
 */
public class Constants {


    public static final Long MAX_AGE_SECS = 3600L;
    public static final String RESOURCE_ID = "PeerConnect-API";


    //#region Token Service

    public static final String ACCESS_TOKEN_INSERT_STATEMENT = "INSERT INTO OAuth_AccessTokens (tokenId, token, authenticationId, userName, clientId, authentication, refreshToken) VALUES (?, ?, ?, ?, ?, ?, ?)";

    public static final String ACCESS_TOKEN_SELECT_STATEMENT = "SELECT tokenId, token FROM OAuth_AccessTokens WHERE tokenId = ?";

    public static final String ACCESS_TOKEN_AUTHENTICATION_SELECT_STATEMENT = "SELECT tokenId, authentication FROM OAuth_AccessTokens WHERE tokenId = ?";

    public static final String ACCESS_TOKEN_FROM_AUTHENTICATION_SELECT_STATEMENT = "SELECT tokenId, token FROM OAuth_AccessTokens WHERE authenticationId = ?";

    public static final String ACCESS_TOKENS_FROM_USERNAME_AND_CLIENT_SELECT_STATEMENT = "SELECT tokenId, token FROM OAuth_AccessTokens WHERE userName = ? and clientId = ?";

    public static final String ACCESS_TOKENS_FROM_USERNAME_SELECT_STATEMENT = "SELECT tokenId, token FROM OAuth_AccessTokens WHERE userName = ?";

    public static final String ACCESS_TOKENS_FROM_CLIENTID_SELECT_STATEMENT = "SELECT tokenId, token FROM OAuth_AccessTokens WHERE clientId = ?";

    public static final String ACCESS_TOKEN_DELETE_STATEMENT = "DELETE FROM OAuth_AccessTokens WHERE tokenId = ?";

    public static final String ACCESS_TOKEN_DELETE_FROM_REFRESH_TOKEN_STATEMENT = "DELETE FROM OAuth_AccessTokens WHERE refreshToken = ?";

    public static final String REFRESH_TOKEN_INSERT_STATEMENT = "INSERT INTO OAuth_RefreshTokens (tokenId, token, authentication) VALUES (?, ?, ?)";

    public static final String REFRESH_TOKEN_SELECT_STATEMENT = "SELECT tokenId, token FROM OAuth_RefreshTokens WHERE tokenId = ?";

    public static final String REFRESH_TOKEN_AUTHENTICATION_SELECT_STATEMENT = "SELECT tokenId, authentication FROM OAuth_RefreshTokens WHERE tokenId = ?";

    public static final String REFRESH_TOKEN_DELETE_STATEMENT = "DELETE FROM OAuth_RefreshTokens WHERE tokenId = ?";

    //#endregion

    //#region Client Service

    private static final String CLIENT_FIELDS_FOR_UPDATE = "resourceIds, scope, authorizedGrantTypes, "
        + "webServerRedirectUri, authorities, accessTokenValidity, "
        + "refreshTokenValidity, additionalInformation, autoApprove";

    private static final String CLIENT_FIELDS = "clientSecret, " + CLIENT_FIELDS_FOR_UPDATE;

    private static final String BASE_FIND_STATEMENT = "SELECT clientId, " + CLIENT_FIELDS + " FROM OAuth_ClientDetails";

    public static final String CLIENT_FIND_STATEMENT = BASE_FIND_STATEMENT + " ORDER BY clientId";

    public static final String CLIENT_SELECT_STATEMENT = BASE_FIND_STATEMENT + " WHERE clientId = ?";

    public static final String CLIENT_INSERT_STATEMENT = "INSERT INTO OAuth_ClientDetails (" + CLIENT_FIELDS
        + ", clientId) VALUES (?,?,?,?,?,?,?,?,?,?,?)";

    public static final String CLIENT_UPDATE_STATEMENT = "UPDATE OAuth_ClientDetails SET "
        + CLIENT_FIELDS_FOR_UPDATE.replaceAll(", ", "=?, ") + "=? WHERE clientId = ?";

    public static final String CLIENT_UPDATE_SECRET_STATEMENT = "UPDATE OAuth_ClientDetails SET clientSecret = ? WHERE clientId = ?";

    public static final String CLIENT_DELETE_STATEMENT = "DELETE FROM OAuth_ClientDetails WHERE clientId = ?";

    //#endregion

}

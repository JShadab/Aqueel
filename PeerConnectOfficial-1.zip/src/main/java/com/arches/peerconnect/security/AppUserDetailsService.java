package com.arches.peerconnect.security;


import com.arches.peerconnect.repos.UsersRepository;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Service
public class AppUserDetailsService implements UserDetailsService {

    private final UsersRepository repository;

    @Autowired
    public AppUserDetailsService(UsersRepository repository) {
        this.repository = repository;
    }

    @Override
    @Transactional(readOnly = true)
    public UserDetails loadUserByUsername(String email) throws UsernameNotFoundException {
        var user = repository.findByEmail(email)
            .orElseThrow(() -> new UsernameNotFoundException("User not found with email: " + email));

        return UserPrincipal.create(user);
    }

    public UserDetails loadUserById(UUID id) {
        var user = repository.findById(id).orElseThrow(() -> new UsernameNotFoundException("User not found with id" + id));

        return UserPrincipal.create(user);
    }

}

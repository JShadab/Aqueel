package com.arches.peerconnect.security;


import com.arches.peerconnect.entities.peerconnect.User;

import lombok.Getter;
import lombok.Setter;
import lombok.extern.slf4j.Slf4j;

import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.UserDetails;

import java.util.Collection;
import java.util.Map;
import java.util.UUID;
import java.util.stream.Collectors;


/**
 * @author Anurag Mishra, 2018-12-24
 */
@Getter
@Setter
@Slf4j
public class UserPrincipal implements UserDetails {

    private UUID id;
    private UUID campaignId;
    private String email;
    private String password;
    private Boolean isActive;
    private Collection<? extends GrantedAuthority> authorities;
    private Map<String, Object> attributes;


    public UserPrincipal(UUID id, UUID campaignId, String email, String password, Boolean isActive, Collection<? extends GrantedAuthority> authorities) {
        this.id = id;
        this.campaignId = campaignId;
        this.email = email;
        this.password = password;
        this.isActive = isActive;
        this.authorities = authorities;
    }

    public static UserPrincipal create(User user) {
        var authorities = user.getRoles()
                              .stream()
                              .map(SimpleGrantedAuthority::new)
                              .collect(Collectors.toList());
        log.info("ROLES: {}", authorities);

        return new UserPrincipal(user.getId(), user.getCampaignId(), user.getEmail(), user.getPassword(), user.getIsActive(), authorities);
    }

    public static UserPrincipal create(User user, Map<String, Object> attributes) {
        UserPrincipal userPrincipal = UserPrincipal.create(user);
        userPrincipal.setAttributes(attributes);
        return userPrincipal;
    }

    @Override
    public String getUsername() {
        return email;
    }

    @Override
    public boolean isEnabled() {
        return isActive;
    }

    @Override
    public boolean isAccountNonExpired() {
        return true;
    }

    @Override
    public boolean isAccountNonLocked() {
        return true;
    }

    @Override
    public boolean isCredentialsNonExpired() {
        return true;
    }

}

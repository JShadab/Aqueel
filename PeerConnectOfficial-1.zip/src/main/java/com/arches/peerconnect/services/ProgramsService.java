package com.arches.peerconnect.services;


import com.arches.peerconnect.entities.Parent;
import com.arches.peerconnect.entities.enums.ErrorCode;
import com.arches.peerconnect.entities.peerconnect.Program;
import com.arches.peerconnect.exceptions.ApiException;
import com.arches.peerconnect.models.request.ProgramRequest;
import com.arches.peerconnect.repos.ParentsRepository;
import com.arches.peerconnect.repos.ProgramsRepository;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.UUID;


/**
 * @author Anurag Mishra, 2018-12-26
 */
@Service
public class ProgramsService {

    private final ProgramsRepository programsRepository;
    private final ParentsRepository parentsRepository;

    public ProgramsService(
        ProgramsRepository programsRepository,
        ParentsRepository parentsRepository) {

        this.programsRepository = programsRepository;
        this.parentsRepository = parentsRepository;

    }

    public List<Program> getAllByCampaignId(UUID campaignId) {

        return programsRepository
                    .getAllByCampaign_Id(campaignId);

    }

    public Program getByCampaignId(UUID campaignId, UUID programId) {

        return programsRepository
                   .getByCampaign_IdAndId(campaignId, programId)
                   .orElseThrow(() -> new ApiException(ErrorCode.E034));

    }

    public Program create(UUID tenantId, ProgramRequest request) {

        var campaign = getCampaign(tenantId);
        var program = Program.fromRequest(request);
        program.setCampaign(campaign);

        return programsRepository.save(program);

    }

    public void update(UUID tenantId, UUID programId, ProgramRequest request) {

        var campaign = getCampaign(tenantId);
        var program = programsRepository
                          .findById(programId)
                          .orElseThrow(() -> new ApiException(ErrorCode.E034));

        program.setCampaign(campaign);
        program.updateFromRequest(request);

        programsRepository.save(program);
    }


    //

    private Parent getCampaign(UUID tenantId) {
        return parentsRepository
                   .findById(tenantId)
                   .orElseThrow(() -> new ApiException(ErrorCode.E035));
    }
}

package com.arches.peerconnect.models.request;


import com.fasterxml.jackson.annotation.JsonFormat;
import lombok.Data;

import javax.validation.constraints.Email;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;

import java.util.Date;


/**
 * @author Anurag Mishra, 2018-12-26
 */
@Data
public class ProgramRequest {

    @NotEmpty
    private String name;

    @NotNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
    private Date startUtc;

    @NotNull
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ssXXX")
    private Date endUtc;

    @NotNull
    private int appointmentDuration;

    @NotNull
    private int maxParticipantAppts;

    @NotNull
    private int maxCaptainAppts;

    @NotEmpty
    @Email
    private String supportEmail;

    @NotNull
    private Boolean isActive;

}

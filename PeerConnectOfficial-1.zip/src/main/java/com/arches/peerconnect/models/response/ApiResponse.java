package com.arches.peerconnect.models.response;


import com.arches.peerconnect.entities.enums.ErrorCode;
import lombok.Value;


/**
 * @author Anurag Mishra, 2018-12-25
 */
@Value
public class ApiResponse {

    private final Boolean success;

    private final String code;

    private final String message;

    //

    public static ApiResponse OK = new ApiResponse(true, ErrorCode.S200.toString(), ErrorCode.S200.getDescription());

    public static ApiResponse from(ErrorCode code) {
        return new ApiResponse(code.equals(ErrorCode.S200), code.toString(), code.getDescription());
    }
}

INSERT INTO [dbo].[PC_Roles]
  (campaignId, name)
VALUES
  ('3723137b-9674-4892-a883-c3eefd67d367', 'MD/DO'),
  ('3723137b-9674-4892-a883-c3eefd67d367', 'DMD'),
  ('3723137b-9674-4892-a883-c3eefd67d367', 'DDS'),
  ('3723137b-9674-4892-a883-c3eefd67d367', 'PharmD/RPh'),
  ('3723137b-9674-4892-a883-c3eefd67d367', 'PA'),
  ('3723137b-9674-4892-a883-c3eefd67d367', 'CRNA/NP/APRN'),
  ('3723137b-9674-4892-a883-c3eefd67d367', 'RN'),
  ('3723137b-9674-4892-a883-c3eefd67d367', 'Other');


INSERT INTO  [dbo].[Parents]
  (id, name, level, isActive, parentId)
VALUES
  ('a6dee8cb-9a03-4cd4-8fb7-a27254bf91fc', 'Entrada', 0, 1, NULL),
  ('7d16f66e-325c-45fe-b9c9-a57bda3e70d6', 'Johnson & Johnson', 1, 1, 'a6dee8cb-9a03-4cd4-8fb7-a27254bf91fc'),
  ('3c1304fa-dd00-4a72-a9c8-674c5cdb847c', 'DePuy Synthes', 2, 1, '7d16f66e-325c-45fe-b9c9-a57bda3e70d6'),
  ('3723137b-9674-4892-a883-c3eefd67d367', 'Knowledge Exchange', 3, 1, '3c1304fa-dd00-4a72-a9c8-674c5cdb847c');

INSERT INTO  [dbo].[Admins]
  (id, firstName, lastName, email,
   password, isActive, parentId)
VALUES
  ('67d8a2e6-b85f-4e0b-8036-be60a27d38ec', 'KnowEx', 'Admin', 'ke.admin@dps.com',
   /*ke-admin*/'$2a$10$uaBPNT4Jtd9fC7BVELGCxOec2vKnz03DKl2jIumRNNrvXUlOydWEy', 1, '3723137b-9674-4892-a883-c3eefd67d367');

INSERT INTO  [dbo].[Roles]
  (id, name)
VALUES
  ('440c5070-9834-4206-b50d-b777b0059a5e', 'ROLE_TENANT_ADMIN'),
  ('c9453ef6-b77b-4cae-8c93-df5cd0464236', 'ROLE_CLIENT_ADMIN'),
  ('d99f12d5-ad27-4c7a-96de-72a0086391b8', 'ROLE_BRAND_ADMIN'),
  ('a6901329-cc24-4d30-850f-f9ffe820cfd9', 'ROLE_CAMPAIGN_ADMIN');

INSERT INTO  [dbo].[AdminRoles]
  (adminId, roleId)
VALUES
  ('67d8a2e6-b85f-4e0b-8036-be60a27d38ec', 'a6901329-cc24-4d30-850f-f9ffe820cfd9')

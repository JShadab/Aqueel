INSERT INTO [dbo].[OAuth_ClientDetails] (
  clientId, clientSecret, resourceIds,
  scope, authorizedGrantTypes, accessTokenValidity, refreshTokenValidity)
VALUES
  ('oauth-admin-client', /*oauth-admin-password*/'$2a$10$FdaR5DgESdPmRqfdRzmOCeL142StW.0EANPz3gk84yh4nG1J8X4n2', 'PeerConnect-API',
   'read,write,admin', 'authorization_code,implicit,password,refresh_token', 1 * 60 * 60, 6 * 60 * 60),
  ('oauth-user-client', /*oauth-user-password*/'$2a$10$O5W8qrfRpoEDuHaPrk5ynuSJHUqNIsvWjf2aB7IUSFVZk8rn5Goei', 'PeerConnect-API',
   'read,write,user', 'authorization_code,implicit,password,refresh_token', 1 * 60 * 60, 6 * 60 * 60);

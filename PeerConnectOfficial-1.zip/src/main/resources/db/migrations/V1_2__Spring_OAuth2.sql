CREATE TABLE OAuth_ClientDetails (
  clientId VARCHAR(256) PRIMARY KEY,
  resourceIds VARCHAR(256),
  clientSecret VARCHAR(256),
  scope VARCHAR(256),
  authorizedGrantTypes VARCHAR(256),
  webServerRedirectUri VARCHAR(256),
  authorities VARCHAR(256),
  accessTokenValidity INTEGER,
  refreshTokenValidity INTEGER,
  additionalInformation VARCHAR(4096),
  autoApprove VARCHAR(256)
);

CREATE TABLE OAuth_AccessTokens (
  tokenId VARCHAR(256),
  token VARBINARY(MAX),
  authenticationId VARCHAR(256) PRIMARY KEY,
  userName VARCHAR(256),
  clientId VARCHAR(256),
  authentication VARBINARY(MAX),
  refreshToken VARCHAR(256)
);

CREATE TABLE OAuth_RefreshTokens (
  tokenId VARCHAR(256),
  token VARBINARY(MAX),
  authentication VARBINARY(MAX)
);

CREATE TABLE OAuth_ClientTokens (
  tokenId VARCHAR(256),
  token VARBINARY(MAX),
  authenticationId VARCHAR(256) PRIMARY KEY,
  userName VARCHAR(256),
  clientId VARCHAR(256)
);

CREATE TABLE OAuth_Codes (
  code VARCHAR(256), authentication VARBINARY(MAX)
);

CREATE TABLE OAuth_Approvals (
	userId VARCHAR(256),
	clientId VARCHAR(256),
	scope VARCHAR(256),
	status VARCHAR(10),
	expiresAt DATETIME2,
	lastModifiedAt DATETIME2
);

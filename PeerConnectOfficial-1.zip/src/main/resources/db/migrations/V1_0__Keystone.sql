-- PARENTS

CREATE TABLE [dbo].[Parents] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [parentId]   UNIQUEIDENTIFIER     NULL,

  [name]       VARCHAR(50)      NOT NULL,
  [level]      INT              NOT NULL,
  [isActive]   BIT              NOT NULL DEFAULT (0),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_Parents]       PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_ParentsParent] FOREIGN KEY ([parentId]) REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_ParentsParent] ON [dbo].[Parents] ( [parentId] ASC )
GO

-- ADMINS

CREATE TABLE [dbo].[Admins] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [parentId]   UNIQUEIDENTIFIER     NULL,

  [firstName]  VARCHAR(50)      NOT NULL,
  [lastName]   VARCHAR(50)      NOT NULL,
  [email]      VARCHAR(255)     NOT NULL,
  [password]   VARCHAR(MAX)     NOT NULL,
  [isActive]   BIT              NOT NULL DEFAULT (0),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_Admins]       PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_AdminsParent] FOREIGN KEY ([parentId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_UserParent] ON [dbo].[Admins] ( [parentId] ASC )
GO

-- ROLES

CREATE TABLE [dbo].[Roles] (
  [id]      UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [name]    VARCHAR(30)      NOT NULL,

  CONSTRAINT [PK_Roles] PRIMARY KEY CLUSTERED ([id] ASC)
);
GO

-- ADMIN ROLES

CREATE TABLE [dbo].[AdminRoles]
(
  [adminId]  UNIQUEIDENTIFIER NOT NULL,
  [roleId]   UNIQUEIDENTIFIER NOT NULL,

  CONSTRAINT [PK_AdminRoles] PRIMARY KEY CLUSTERED ([adminId] ASC, [roleId] ASC),
  CONSTRAINT [FK_AdminRolesAdmin] FOREIGN KEY ([adminId])  REFERENCES [dbo].[Admins]([id]),
  CONSTRAINT [FK_AdminRolesRole] FOREIGN KEY ([roleId])  REFERENCES [dbo].[Roles]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_AdminRolesAdmin] ON [dbo].[AdminRoles] ( [adminId] ASC )
GO

CREATE NONCLUSTERED INDEX [FKIDX_AdminRolesRole] ON [dbo].[AdminRoles] ( [roleId] ASC )
GO


-- DEFAULT QUESTIONS

CREATE TABLE [dbo].[DefaultQuestions] (
  [id]          UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [name]        VARCHAR(50)      NOT NULL,
  [description] VARCHAR(255)     NOT NULL,
  [type]        VARCHAR(10)      NOT NULL,
  [attribute]   VARCHAR(10)      NOT NULL,
  [isActive]    BIT              NOT NULL DEFAULT (1),

  [createdBy]   UNIQUEIDENTIFIER     NULL,
  [createdOn]   DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy]  UNIQUEIDENTIFIER     NULL,
  [modifiedOn]  DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_Questions] PRIMARY KEY CLUSTERED ([id] ASC)
);
GO

-- DEFAULT QUESTION OPTIONS

CREATE TABLE [dbo].[DefaultQuestionOptions] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [questionId] UNIQUEIDENTIFIER NOT NULL,

  [value]      VARCHAR(255)     NOT NULL,
  [text]       VARCHAR(255)         NULL,
  [isActive]   BIT              NOT NULL DEFAULT (1),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_QuestionOptions]          PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_QuestionOptionsQuestion]  FOREIGN KEY ([questionId]) REFERENCES [dbo].[DefaultQuestions]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_QuestionOptionsQuestion] ON [dbo].[DefaultQuestionOptions] ( [questionId] ASC )
GO


-- CONTENTS

CREATE TABLE [dbo].[Contents] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId] UNIQUEIDENTIFIER NOT NULL,

  [name]       VARCHAR(50)      NOT NULL,
  [channel]    VARCHAR(10)      NOT NULL,                       -- email | sms
  [category]   VARCHAR(50)          NULL,
  [subject]    VARCHAR(MAX)         NULL,
  [preHeader]  VARCHAR(MAX)         NULL,
  [text]       VARCHAR(MAX)     NOT NULL,
  [fileName]   VARCHAR(50)          NULL,

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_Contents]          PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_ContentsCampaign]  FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_ContentsCampaign] ON [dbo].[Contents] ( [campaignId] ASC )
GO


-- CAMPAIGN QUESTIONS

CREATE TABLE [dbo].[CampaignQuestions] (
  [id]           UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId]   UNIQUEIDENTIFIER NOT NULL,

  [name]         VARCHAR(50)      NOT NULL,
  [description]  VARCHAR(255)     NOT NULL,
  [type]         VARCHAR(10)      NOT NULL,            -- text, checkbox, radio, select, rating
  [dataType]     VARCHAR(10)      NOT NULL,            -- text: text, email, hidden, number, password | checkbox: single, multiple, multipleOther
  [isEvent]      BIT              NOT NULL DEFAULT (0),

  [createdBy]    UNIQUEIDENTIFIER     NULL,
  [createdOn]    DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy]   UNIQUEIDENTIFIER     NULL,
  [modifiedOn]   DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_CampaignQuestions]         PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_CampaignQuestionsCampaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO


CREATE NONCLUSTERED INDEX [FKIDX_CampaignQuestionsCampaign] ON [dbo].[CampaignQuestions] ( [campaignId] ASC )
GO

-- CAMPAIGN QUESTION OPTIONS

CREATE TABLE [dbo].[CampaignQuestionOptions] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [questionId] UNIQUEIDENTIFIER NOT NULL,

  [value]      VARCHAR(255)     NOT NULL,
  [text]       VARCHAR(255)         NULL,

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_CampaignQuestionOptions]                 PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_CampaignQuestionOptionsCampaignQuestion] FOREIGN KEY ([questionId])  REFERENCES [dbo].[CampaignQuestions]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_CampaignQuestionOptionsCampaignQuestion] ON [dbo].[CampaignQuestionOptions] ( [questionId] ASC )
GO


-- SURVEYS

CREATE TABLE [dbo].[Surveys] (
  [id]           UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId]   UNIQUEIDENTIFIER NOT NULL,

  [name]         VARCHAR(100)     NOT NULL,
  [shortUrl]     VARCHAR(50)          NULL,
  [isEnrollment] BIT              NOT NULL DEFAULT (0),

  [createdBy]    UNIQUEIDENTIFIER     NULL,
  [createdOn]    DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy]   UNIQUEIDENTIFIER     NULL,
  [modifiedOn]   DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_Surveys]         PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_SurveysCampaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_SurveysCampaign] ON [dbo].[Surveys] ( [campaignId] ASC )
GO

-- ENROLLMENTS

CREATE TABLE [dbo].[Enrollments] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId] UNIQUEIDENTIFIER NOT NULL,
  [surveyId]   UNIQUEIDENTIFIER NOT NULL,

  [response]   NVARCHAR(MAX)    NOT NULL,
  [isActive]   BIT              NOT NULL DEFAULT (1),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_Enrollments]         PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_EnrollmentsCampaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id]),
  CONSTRAINT [FK_EnrollmentsSurvey]   FOREIGN KEY ([surveyId])    REFERENCES [dbo].[Surveys]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_EnrollmentsSurvey] ON [dbo].[Enrollments] ( [surveyId] ASC )
GO

-- SURVEY RESPONSES

CREATE TABLE [dbo].[SurveyResponses] (
  [id]           UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [surveyId]     UNIQUEIDENTIFIER NOT NULL,
  [userId] UNIQUEIDENTIFIER NOT NULL,

  [response]     NVARCHAR(MAX)    NOT NULL,

  [createdBy]    UNIQUEIDENTIFIER     NULL,
  [createdOn]    DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy]   UNIQUEIDENTIFIER     NULL,
  [modifiedOn]   DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_SurveyResponses]           PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_SurveyResponsesSurvey]     FOREIGN KEY ([surveyId])      REFERENCES [dbo].[Surveys]([id]),
  CONSTRAINT [FK_SurveyResponsesEnrollment] FOREIGN KEY ([userId])  REFERENCES [dbo].[Enrollments]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_SurveyResponsesSurvey] ON [dbo].[SurveyResponses] ( [surveyId] ASC )
GO

CREATE NONCLUSTERED INDEX [FKIDX_SurveyResponsesEnrollment] ON [dbo].[SurveyResponses] ( [userId] ASC )
GO


-- SEGMENTS

CREATE TABLE [dbo].[Segments] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId] UNIQUEIDENTIFIER NOT NULL,

  [name]       VARCHAR(50)      NOT NULL,
  [ruleSets]   VARCHAR(MAX)     NOT NULL,
  [isActive]   BIT              NOT NULL DEFAULT (0),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_Segments]          PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_SegmentsCampaign]  FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_SegmentsCampaign] ON [dbo].[Segments] ( [campaignId] ASC )
GO

-- JOURNEYS

CREATE TABLE [dbo].[Journeys] (
  [id]          UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [segmentId]   UNIQUEIDENTIFIER NOT NULL,

  [name]        VARCHAR(50)      NOT NULL,
  [description] VARCHAR(255)         NULL,
  [isActive]    BIT              NOT NULL DEFAULT (0),

  [createdBy]   UNIQUEIDENTIFIER     NULL,
  [createdOn]   DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy]  UNIQUEIDENTIFIER     NULL,
  [modifiedOn]  DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_Journeys]        PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_JourneysSegment] FOREIGN KEY ([segmentId])  REFERENCES [dbo].[Segments]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_JourneysSegment] ON [dbo].[Journeys] ( [segmentId] ASC )
GO


-- SURVEY QUESTIONS

CREATE TABLE [dbo].[SurveyQuestions] (
  [id]          UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [surveyId]    UNIQUEIDENTIFIER NOT NULL,

  [name]        VARCHAR(50)      NOT NULL,
  [description] VARCHAR(255)     NOT NULL,
  [type]        VARCHAR(10)      NOT NULL,
  [dataType]    VARCHAR(10)      NOT NULL,
  [isEvent]     BIT              NOT NULL DEFAULT (0),

  [createdBy]   UNIQUEIDENTIFIER     NULL,
  [createdOn]   DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy]  UNIQUEIDENTIFIER     NULL,
  [modifiedOn]  DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_SurveyQuestions]       PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_SurveyQuestionsSurvey] FOREIGN KEY ([surveyId])  REFERENCES [dbo].[Surveys]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_SurveyQuestionsSurvey] ON [dbo].[SurveyQuestions] ( [surveyId] ASC )
GO

-- SURVEY QUESTION OPTIONS

CREATE TABLE [dbo].[SurveyQuestionOptions] (
  [id]         UNIQUEIDENTIFIER NOT NULL,
  [questionId] UNIQUEIDENTIFIER NOT NULL,

  [value]      VARCHAR(255)     NOT NULL,
  [text]       VARCHAR(255)         NULL,

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_SurveyQuestionOptions]               PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_SurveyQuestionOptionsSurveyQuestion] FOREIGN KEY ([questionId])  REFERENCES [dbo].[SurveyQuestions]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_SurveyQuestionOptionsSurveyQuestion] ON [dbo].[SurveyQuestionOptions] ( [questionId] ASC )
GO


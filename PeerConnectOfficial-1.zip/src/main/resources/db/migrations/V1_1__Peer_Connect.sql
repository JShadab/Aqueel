---------- [ T A B L E S ] ----------

-- PROGRAMS

CREATE TABLE [dbo].[PC_Programs] (
  [id]                     UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId]             UNIQUEIDENTIFIER NOT NULL,

  [name]                   VARCHAR(255)     NOT NULL,
  [startDate]              DATETIME2        NOT NULL,
  [endDate]                DATETIME2        NOT NULL,
  [sessionDuration]        INT              NOT NULL,
  [maxCaptainSessions]     INT              NOT NULL,
  [maxParticipantSessions] INT              NOT NULL,
  [supportEmail]           VARCHAR(255)     NOT NULL,
  [isActive]               BIT              NOT NULL DEFAULT (1),

  [createdBy]              UNIQUEIDENTIFIER     NULL,
  [createdOn]              DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy]             UNIQUEIDENTIFIER     NULL,
  [modifiedOn]             DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_PC_Programs]         PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_ProgramsCampaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_ProgramsCampaign] ON [dbo].[PC_Programs] ( [campaignId] ASC )
GO

-- SUPPORT TOPICS

CREATE TABLE [dbo].[PC_SupportTopics] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId] UNIQUEIDENTIFIER NOT NULL,

  [name]       VARCHAR(255)     NOT NULL,
  [isActive]   BIT              NOT NULL DEFAULT (1),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_PC_SupportTopics]         PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_SupportTopicsCampaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_SupportTopicsCampaign] ON [dbo].[PC_SupportTopics] ( [campaignId] ASC )
GO

-- TIME ZONES

CREATE TABLE [dbo].[PC_TimeZones] (
  [id]           UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId]   UNIQUEIDENTIFIER NOT NULL,

  [label]        VARCHAR(255)     NOT NULL,
  [utcOffset]    INT              NOT NULL,
  [dstOffset]    INT              NOT NULL,
  [isActive]     BIT              NOT NULL DEFAULT (1),

  [createdBy]    UNIQUEIDENTIFIER     NULL,
  [createdOn]    DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy]   UNIQUEIDENTIFIER     NULL,
  [modifiedOn]   DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_PC_TimeZones]         PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_TimeZonesCampaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_TimeZonesCampaign] ON [dbo].[PC_TimeZones] ( [campaignId] ASC )
GO

-- SPECIALITIES

CREATE TABLE [dbo].[PC_Specialities] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId] UNIQUEIDENTIFIER NOT NULL,

  [name]       VARCHAR(255)     NOT NULL,
  [isActive]   BIT              NOT NULL DEFAULT (1),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_PC_Specialities]         PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_SpecialitiesCampaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_SpecialitiesCampaign] ON [dbo].[PC_Specialities] ( [campaignId] ASC )
GO

-- SEGMENTS

CREATE TABLE [dbo].[PC_Segments] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId] UNIQUEIDENTIFIER NOT NULL,

  [name]       VARCHAR(255)     NOT NULL,
  [isActive]   BIT              NOT NULL DEFAULT (1),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_PC_Segments]         PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_SegmentsCampaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_SegmentsCampaign] ON [dbo].[PC_Segments] ( [campaignId] ASC )
GO

-- AFFILIATIONS

CREATE TABLE [dbo].[PC_Affiliations] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId] UNIQUEIDENTIFIER NOT NULL,

  [name]       VARCHAR(255)     NOT NULL,
  [isActive]   BIT              NOT NULL DEFAULT (1),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_PC_Affiliations]         PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_AffiliationsCampaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_AffiliationsCampaign] ON [dbo].[PC_Affiliations] ( [campaignId] ASC )
GO

-- ROLES

CREATE TABLE [dbo].[PC_Roles] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId] UNIQUEIDENTIFIER NOT NULL,

  [name]       VARCHAR(255)     NOT NULL,
  [isActive]   BIT              NOT NULL DEFAULT (1),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_PC_Roles]         PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_RolesCampaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_RolesCampaign] ON [dbo].[PC_Roles] ( [campaignId] ASC )
GO

-- TOPICS

CREATE TABLE [dbo].[PC_Topics] (
  [id]         UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId] UNIQUEIDENTIFIER NOT NULL,

  [name]       VARCHAR(255)     NOT NULL,
  [isActive]   BIT              NOT NULL DEFAULT (1),

  [createdBy]  UNIQUEIDENTIFIER     NULL,
  [createdOn]  DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy] UNIQUEIDENTIFIER     NULL,
  [modifiedOn] DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_PC_Topics]         PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_TopicsCampaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_TopicsCampaign] ON [dbo].[PC_Topics] ( [campaignId] ASC )
GO

-- RESOURCE FOLDERS

CREATE TABLE [dbo].[PC_ResourceFolders] (
  [id]             UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId]     UNIQUEIDENTIFIER NOT NULL,
  [topicId]        UNIQUEIDENTIFIER     NULL,
  [featResourceId] UNIQUEIDENTIFIER     NULL,

  [name]           VARCHAR(255)     NOT NULL,
  [isRestricted]   BIT              NOT NULL DEFAULT (0),
  [isActive]       BIT              NOT NULL DEFAULT (1),

  [createdBy]      UNIQUEIDENTIFIER     NULL,
  [createdOn]      DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy]     UNIQUEIDENTIFIER     NULL,
  [modifiedOn]     DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_PC_ResourceFolders]         PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_ResourceFoldersCampaign] FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id]),
  CONSTRAINT [FK_PC_ResourceFoldersTopic]    FOREIGN KEY ([topicId])     REFERENCES [dbo].[PC_Topics]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_ResourceFoldersCampaign] ON [dbo].[PC_ResourceFolders] ( [campaignId] ASC )
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_ResourceFoldersTopic] ON [dbo].[PC_ResourceFolders] ( [topicId] ASC )
GO

-- RESOURCES

CREATE TABLE [dbo].[PC_Resources] (
  [id]           UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [campaignId]   UNIQUEIDENTIFIER NOT NULL,
  [folderId]     UNIQUEIDENTIFIER     NULL,

  [name]         VARCHAR(255)     NOT NULL,
  [description]  VARCHAR(MAX)     NOT NULL,
  [contentType]  INT              NOT NULL,                     -- PDF | VIDEO | ...
  [absoluteUrl]  VARCHAR(MAX)     NOT NULL,
  [thumbnailUrl] VARCHAR(MAX)     NOT NULL,
  [isActive]     BIT              NOT NULL DEFAULT (1),

  [createdBy]    UNIQUEIDENTIFIER     NULL,
  [createdOn]    DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy]   UNIQUEIDENTIFIER     NULL,
  [modifiedOn]   DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_PC_Resources]               PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_ResourcesCampaign]       FOREIGN KEY ([campaignId])  REFERENCES [dbo].[Parents]([id]),
  CONSTRAINT [FK_PC_ResourcesResourceFolder] FOREIGN KEY ([folderId])    REFERENCES [dbo].[PC_ResourceFolders]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_ResourcesCampaign] ON [dbo].[PC_Resources] ( [campaignId] ASC )
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_ResourcesResourceFolder] ON [dbo].[PC_Resources] ( [folderId] ASC )
GO

-- RESOURCE RATINGS

CREATE TABLE [dbo].[PC_ResourceRatings] (
  [id]           UNIQUEIDENTIFIER NOT NULL DEFAULT (NEWID()),
  [resourceId]   UNIQUEIDENTIFIER NOT NULL,
  [userId]       UNIQUEIDENTIFIER NOT NULL,

  [score]        INT              NOT NULL DEFAULT (0),

  [createdBy]    UNIQUEIDENTIFIER     NULL,
  [createdOn]    DATETIME2        NOT NULL DEFAULT (GETDATE()),
  [modifiedBy]   UNIQUEIDENTIFIER     NULL,
  [modifiedOn]   DATETIME2        NOT NULL DEFAULT (GETDATE()),

  CONSTRAINT [PK_PC_ResourceRatings]         PRIMARY KEY CLUSTERED ([id] ASC),
  CONSTRAINT [FK_PC_ResourceRatingsResource] FOREIGN KEY ([resourceId])  REFERENCES [dbo].[PC_Resources]([id]),
  CONSTRAINT [FK_PC_ResourceRatingsUser]     FOREIGN KEY ([userId])      REFERENCES [dbo].[Enrollments]([id])
);
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_ResourceRatingsResource] ON [dbo].[PC_ResourceRatings] ( [resourceId] ASC )
GO

CREATE NONCLUSTERED INDEX [FKIDX_PC_ResourceRatingsUser] ON [dbo].[PC_ResourceRatings] ( [userId] ASC )
GO


---------- [ V I E W S ] ----------

-- USERS

CREATE VIEW [dbo].[PC_Users]
AS
  SELECT e.id,
         e.campaignId,
         JSON_VALUE(e.response, '$.emailAddress') AS email,
         JSON_VALUE(e.response, '$.password') AS password,
         e.isActive,
         (IIF(JSON_VALUE(e.response, '$.type') = 'Captain',
            'ROLE_CAPTAIN', 'ROLE_PARTICIPANT') + ',ROLE_USER') AS rolesList
  FROM   [dbo].[Enrollments] e
  UNION
  SELECT a.id, a.parentId AS campaignId, a.email, a.password, a.isActive,
         (SELECT STRING_AGG(r.name, ',')
          FROM   [dbo].[AdminRoles] ar
                 LEFT JOIN [dbo].[Roles] r ON ar.roleId = r.id
          WHERE  ar.adminId = a.id) + ',ROLE_ADMIN' AS roles
  FROM   [dbo].[Admins] a;
GO

-- CAPTAINS

CREATE VIEW [dbo].[PC_Captains]
AS
  SELECT e.id, e.response,
         JSON_VALUE(e.response, '$.firstName')        AS firstName,
         JSON_VALUE(e.response, '$.lastName')         AS lastName,
         JSON_VALUE(e.response, '$.title')            AS title,
         JSON_VALUE(e.response, '$.emailAddress')     AS emailAddress,
         JSON_VALUE(e.response, '$.password')         AS password,
         JSON_VALUE(e.response, '$.mobileNumber')     AS mobileNumber,
         JSON_VALUE(e.response, '$.addressLine1')     AS addressLine1,
         JSON_VALUE(e.response, '$.addressLine2')     AS addressLine2,
         JSON_VALUE(e.response, '$.city')             AS city,
         JSON_VALUE(e.response, '$.state')            AS state,
         JSON_VALUE(e.response, '$.zipCode')          AS zipCode,
         JSON_VALUE(e.response, '$.profileImageUrl')  AS profileImageUrl,
         JSON_VALUE(e.response, '$.biography')        AS biography,
         JSON_VALUE(e.response, '$.optIn')            AS optIn,
         JSON_VALUE(e.response, '$.terms')            AS terms,
         JSON_VALUE(e.response, '$.mediaSourceId')    AS mediaSourceId,
         JSON_VALUE(e.response, '$.affiliationId')    AS affiliationId,
         JSON_VALUE(e.response, '$.roleId')           AS roleId,
         JSON_VALUE(e.response, '$.segmentId')        AS segmentId,
         JSON_VALUE(e.response, '$.specialityId')     AS specialityId,
         JSON_VALUE(e.response, '$.timeZoneId')       AS timeZoneId,
         JSON_VALUE(e.response, '$.topicIds')         AS topicIdsList
  FROM   [dbo].[Enrollments] e
  WHERE  JSON_VALUE(e.response, '$.userType') = 'Captain';
GO

-- PARTICIPANTS

CREATE VIEW [dbo].[PC_Participants]
AS
  SELECT e.id, e.response,
         JSON_VALUE(e.response, '$.firstName')        AS firstName,
         JSON_VALUE(e.response, '$.lastName')         AS lastName,
         JSON_VALUE(e.response, '$.title')            AS title,
         JSON_VALUE(e.response, '$.emailAddress')     AS emailAddress,
         JSON_VALUE(e.response, '$.password')         AS password,
         JSON_VALUE(e.response, '$.mobileNumber')     AS mobileNumber,
         JSON_VALUE(e.response, '$.addressLine1')     AS addressLine1,
         JSON_VALUE(e.response, '$.addressLine2')     AS addressLine2,
         JSON_VALUE(e.response, '$.city')             AS city,
         JSON_VALUE(e.response, '$.state')            AS state,
         JSON_VALUE(e.response, '$.zipCode')          AS zipCode,
         JSON_VALUE(e.response, '$.profileImageUrl')  AS profileImageUrl,
         JSON_VALUE(e.response, '$.biography')        AS biography,
         JSON_VALUE(e.response, '$.optIn')            AS optIn,
         JSON_VALUE(e.response, '$.terms')            AS terms,
         JSON_VALUE(e.response, '$.mediaSourceId')    AS mediaSourceId,
         JSON_VALUE(e.response, '$.affiliationId')    AS affiliationId,
         JSON_VALUE(e.response, '$.roleId')           AS roleId,
         JSON_VALUE(e.response, '$.segmentId')        AS segmentId,
         JSON_VALUE(e.response, '$.specialityId')     AS specialityId,
         JSON_VALUE(e.response, '$.timeZoneId')       AS timeZoneId
  FROM   [dbo].[Enrollments] e
  WHERE  JSON_VALUE(e.response, '$.userType') = 'Participant';
GO

package com.arches.peerconnect.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/***
 * 1. Arches to provide endpoint to ensure that the Participant data can be
 * captured from signup form (Create/Update/Delete/Get by Id/Get by Email) <br>
 * 2. Arches to provide endpoint to ensure that Participant logins can be
 * authenticated <br>
 * 3. Data fields captured within signup form
 **/
@Entity
public class Participant {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	private String firstName;
	private String lastName;
	private String title;

	/**
	 * 1. Not visible on front-end form for Knowledge Exchange, however back-end
	 * should support it <br>
	 * 2. The list of options will be provided by the API
	 **/
	private String specialty;

	/** Going to be used for login **/
	private String email;
	private String password;

	private String mobile;
	private String afiliation;

	/**
	 * 1. Not visible on front-end form for Knowledge Exchange, however back-end
	 * should support it <br>
	 * 2. The list of options will be provided by the API
	 **/
	private String role;

	/** The list of options will be provided by the API */
	private String timezone;

	/**
	 * Not visible on front-end form for Knowledge Exchange, however back-end should
	 * support it.
	 */
	private String addressLine1;

	/**
	 * Not visible on front-end form for Knowledge Exchange, however back-end should
	 * support it.
	 */
	private String addressLine2;

	/**
	 * Not visible on front-end form for Knowledge Exchange, however back-end should
	 * support it.
	 */
	private String city;
	/**
	 * Not visible on front-end form for Knowledge Exchange, however back-end should
	 * support it.
	 */
	private String state;
	/**
	 * Not visible on front-end form for Knowledge Exchange, however back-end should
	 * support it.
	 */
	private String zipCode;

	/**
	 * 1. This will be captured as a multiple choice question on the front-end <br>
	 * 2. The list of options will be provided by the API
	 **/
	private String segment;

	/** Hardcoded for each program�s front-end */
	private String tenantId;
	/** Not sent by front-end, assumed to always be �true� **/
	private boolean optIn;
	/** Not sent by front-end, assumed to always be �true� **/
	private boolean termsConditions;

	/**
	 * 1. Hidden Field, Default to Null <br>
	 * 2. This is used to identify the referral source (if known)<br>
	 * 3. Note: Client plans to send solicitation emails to prospects in 2019
	 **/
	private String mediaSourceId;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getSpecialty() {
		return specialty;
	}

	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getAfiliation() {
		return afiliation;
	}

	public void setAfiliation(String afiliation) {
		this.afiliation = afiliation;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public String getTimezone() {
		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getSegment() {
		return segment;
	}

	public void setSegment(String segment) {
		this.segment = segment;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public boolean isOptIn() {
		return optIn;
	}

	public void setOptIn(boolean optIn) {
		this.optIn = optIn;
	}

	public boolean isTermsConditions() {
		return termsConditions;
	}

	public void setTermsConditions(boolean termsConditions) {
		this.termsConditions = termsConditions;
	}

	public String getMediaSourceId() {
		return mediaSourceId;
	}

	public void setMediaSourceId(String mediaSourceId) {
		this.mediaSourceId = mediaSourceId;
	}

	@Override
	public String toString() {
		return firstName + " " + lastName;
	}
}

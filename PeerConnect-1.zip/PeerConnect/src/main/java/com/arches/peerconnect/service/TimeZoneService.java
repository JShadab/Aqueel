package com.arches.peerconnect.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.arches.peerconnect.repository.TimeZoneRepository;

@Service
public class TimeZoneService {

	@Autowired
	private TimeZoneRepository timeZoneRepository;
}
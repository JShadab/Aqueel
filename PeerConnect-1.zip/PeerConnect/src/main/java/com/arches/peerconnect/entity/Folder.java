package com.arches.peerconnect.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class Folder {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	
	private String name;
	private boolean isRestricted;
	private long topicId;
	private long featuredResourceId;
	private long tenantId;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public boolean isRestricted() {
		return isRestricted;
	}

	public void setRestricted(boolean isRestricted) {
		this.isRestricted = isRestricted;
	}

	public long getTopicId() {
		return topicId;
	}

	public void setTopicId(long topicId) {
		this.topicId = topicId;
	}

	public long getFeaturedResourceId() {
		return featuredResourceId;
	}

	public void setFeaturedResourceId(long featuredResourceId) {
		this.featuredResourceId = featuredResourceId;
	}

	public long getTenantId() {
		return tenantId;
	}

	public void setTenantId(long tenantId) {
		this.tenantId = tenantId;
	}

	@Override
	public String toString() {
		return "Folder [id=" + id + ", name=" + name + ", isRestricted=" + isRestricted + ", topicId=" + topicId
				+ ", featuredResourceId=" + featuredResourceId + ", tenantId=" + tenantId + "]";
	}

}

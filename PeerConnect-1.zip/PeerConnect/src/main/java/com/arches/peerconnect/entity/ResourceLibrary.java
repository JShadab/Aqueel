package com.arches.peerconnect.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class ResourceLibrary {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String name;
	private String description;
	private String resourceAbsoluteUrl;
	private String thumbnailImageUrl;
	private long categoryId;

	/*** (enum?) **/
	private String ContentType;
	private long folderId;
	private long tenantId;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getResourceAbsoluteUrl() {
		return resourceAbsoluteUrl;
	}

	public void setResourceAbsoluteUrl(String resourceAbsoluteUrl) {
		this.resourceAbsoluteUrl = resourceAbsoluteUrl;
	}

	public String getThumbnailImageUrl() {
		return thumbnailImageUrl;
	}

	public void setThumbnailImageUrl(String thumbnailImageUrl) {
		this.thumbnailImageUrl = thumbnailImageUrl;
	}

	public long getCategoryId() {
		return categoryId;
	}

	public void setCategoryId(long categoryId) {
		this.categoryId = categoryId;
	}

	public String getContentType() {
		return ContentType;
	}

	public void setContentType(String contentType) {
		ContentType = contentType;
	}

	public long getFolderId() {
		return folderId;
	}

	public void setFolderId(long folderId) {
		this.folderId = folderId;
	}

	public long getTenantId() {
		return tenantId;
	}

	public void setTenantId(long tenantId) {
		this.tenantId = tenantId;
	}

	@Override
	public String toString() {
		return "Resource [id=" + id + ", name=" + name + ", description=" + description + ", resourceAbsoluteUrl="
				+ resourceAbsoluteUrl + ", thumbnailImageUrl=" + thumbnailImageUrl + ", categoryId=" + categoryId
				+ ", ContentType=" + ContentType + ", folderId=" + folderId + ", tenantId=" + tenantId + "]";
	}

}

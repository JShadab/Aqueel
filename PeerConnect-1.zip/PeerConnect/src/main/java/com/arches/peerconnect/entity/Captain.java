package com.arches.peerconnect.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

/**
 * 1. Arches to provide endpoint to ensure that the Captain data can be uploaded
 * to Keystone (Create/Update/Delete/Get by Id/Get by Email) <br>
 * 2. Arches to provide endpoint to ensure that Captain logins can be
 * authenticated
 **/
@Entity
public class Captain {

	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;

	private String firstName;
	private String lastName;
	private String title;

	/** Going to be used for login */
	private String email;
	private String password;
	private String mobile;
	private String affiliation;

	/** The list of options will be provided by the API */
	private String timezone;

	/**
	 * Not visible on front-end form for Knowledge Exchange, however back-end should
	 * support it.
	 */
	private String addressLine1;

	/**
	 * Not visible on front-end form for Knowledge Exchange, however back-end should
	 * support it.
	 */
	private String addressLine2;

	/**
	 * Not visible on front-end form for Knowledge Exchange, however back-end should
	 * support it.
	 */
	private String city;
	/**
	 * Not visible on front-end form for Knowledge Exchange, however back-end should
	 * support it.
	 */
	private String state;
	/**
	 * Not visible on front-end form for Knowledge Exchange, however back-end should
	 * support it.
	 */
	private String zipCode;

	/**
	 * 1. This will be captured as a multiple choice question on the front-end <br>
	 * 2. The list of options will be provided by the API
	 **/
	private String segment;

	private String biography;

	/** pass as URL **/
	private String profileImage;

	/**
	 * 1. Specify which topics Captain can speak on<br>
	 * The list of options will be provided by the API.
	 */

	private String topics;

	/** Hardcoded for each program�s front-end */
	private String tenantId;

	/**
	 * 1. Not visible on front-end form for Knowledge Exchange, however back-end
	 * should support it<br>
	 * 2. The list of options will be provided by the API
	 */
	private String specialty;

	/**
	 * 1. Not visible on front-end form for Knowledge Exchange, however back-end
	 * should support it <br>
	 * 2. The list of options will be provided by the API
	 */
	private String role;

	/** Not sent by front-end, assumed to always be �true� **/
	private boolean optIn;

	/** Not sent by front-end, assumed to always be �true� **/
	private boolean termsConditions;

	/**
	 * 1. Hidden Field, Default to Null <br>
	 * 2. This is used to identify the referral source (if known)<br>
	 * 3. Note: Client plans to send solicitation emails to prospects in 2019
	 **/
	private String mediaSourceId;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getMobile() {
		return mobile;
	}

	public void setMobile(String mobile) {
		this.mobile = mobile;
	}

	public String getAffiliation() {
		return affiliation;
	}

	public void setAffiliation(String affiliation) {
		this.affiliation = affiliation;
	}

	public String getTimezone() {
		return timezone;
	}

	public void setTimezone(String timezone) {
		this.timezone = timezone;
	}

	public String getAddressLine1() {
		return addressLine1;
	}

	public void setAddressLine1(String addressLine1) {
		this.addressLine1 = addressLine1;
	}

	public String getAddressLine2() {
		return addressLine2;
	}

	public void setAddressLine2(String addressLine2) {
		this.addressLine2 = addressLine2;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getState() {
		return state;
	}

	public void setState(String state) {
		this.state = state;
	}

	public String getZipCode() {
		return zipCode;
	}

	public void setZipCode(String zipCode) {
		this.zipCode = zipCode;
	}

	public String getSegment() {
		return segment;
	}

	public void setSegment(String segment) {
		this.segment = segment;
	}

	public String getBiography() {
		return biography;
	}

	public void setBiography(String biography) {
		this.biography = biography;
	}

	public String getProfileImage() {
		return profileImage;
	}

	public void setProfileImage(String profileImage) {
		this.profileImage = profileImage;
	}

	public String getTopics() {
		return topics;
	}

	public void setTopics(String topics) {
		this.topics = topics;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public String getSpecialty() {
		return specialty;
	}

	public void setSpecialty(String specialty) {
		this.specialty = specialty;
	}

	public String getRole() {
		return role;
	}

	public void setRole(String role) {
		this.role = role;
	}

	public boolean isOptIn() {
		return optIn;
	}

	public void setOptIn(boolean optIn) {
		this.optIn = optIn;
	}

	public boolean isTermsConditions() {
		return termsConditions;
	}

	public void setTermsConditions(boolean termsConditions) {
		this.termsConditions = termsConditions;
	}

	public String getMediaSourceId() {
		return mediaSourceId;
	}

	public void setMediaSourceId(String mediaSourceId) {
		this.mediaSourceId = mediaSourceId;
	}

	@Override
	public String toString() {
		return firstName + " " + lastName;
	}

}

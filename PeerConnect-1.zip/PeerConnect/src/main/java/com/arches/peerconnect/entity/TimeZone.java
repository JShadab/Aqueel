package com.arches.peerconnect.entity;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;

@Entity
public class TimeZone {
	@Id
	@GeneratedValue(strategy = GenerationType.AUTO)
	private long id;
	private String label;

	/** ([+/-]00:00) **/
	private String UTC_Offset;

	/** ([+/-]00:00) **/
	private String UTC_DST_Offset;

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public String getLabel() {
		return label;
	}

	public void setLabel(String label) {
		this.label = label;
	}

	public String getUTC_Offset() {
		return UTC_Offset;
	}

	public void setUTC_Offset(String uTC_Offset) {
		UTC_Offset = uTC_Offset;
	}

	public String getUTC_DST_Offset() {
		return UTC_DST_Offset;
	}

	public void setUTC_DST_Offset(String uTC_DST_Offset) {
		UTC_DST_Offset = uTC_DST_Offset;
	}

	@Override
	public String toString() {
		return "TimeZone [id=" + id + ", label=" + label + ", UTC_Offset=" + UTC_Offset + ", UTC_DST_Offset="
				+ UTC_DST_Offset + "]";
	}

}

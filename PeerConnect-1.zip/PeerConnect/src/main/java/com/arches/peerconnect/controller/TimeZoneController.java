package com.arches.peerconnect.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.arches.peerconnect.service.TimeZoneService;

@Controller
public class TimeZoneController {

	@Autowired
	private TimeZoneService timeZoneService;
}
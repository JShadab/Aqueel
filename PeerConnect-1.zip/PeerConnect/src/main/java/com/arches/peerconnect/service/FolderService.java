package com.arches.peerconnect.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.arches.peerconnect.repository.FolderRepository;

@Service
public class FolderService {
	
	@Autowired
	private FolderRepository folderRepository;
}

package com.arches.peerconnect.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.arches.peerconnect.service.RatingService;

@Controller
public class RatingController {

	@Autowired
	private RatingService ratingService;
}
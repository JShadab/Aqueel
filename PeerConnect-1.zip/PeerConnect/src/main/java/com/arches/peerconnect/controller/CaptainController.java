package com.arches.peerconnect.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.arches.peerconnect.entity.Captain;
import com.arches.peerconnect.service.CaptainService;

@RestController
@EnableAutoConfiguration
public class CaptainController {

	@Autowired
	private CaptainService captainService;
	
	
	@RequestMapping(value="api/captains/getAllCaptains",  method = RequestMethod.GET)
    public List<Captain> getAllCaptain() {
        return captainService.getAllCaptain();
    }
	@RequestMapping(value="api/captains/saveCaptain",  method = RequestMethod.POST)
    public Captain saveCaptain(@RequestBody Captain captain) {
        return captainService.saveCaptain(captain);
    }
}

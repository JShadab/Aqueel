package com.arches.peerconnect.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;

import com.arches.peerconnect.service.AdministratorService;

@Controller
public class AdministratorController {
	
	@Autowired
	private AdministratorService administratorService;
}

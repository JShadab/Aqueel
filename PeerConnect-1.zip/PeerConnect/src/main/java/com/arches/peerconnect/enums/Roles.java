package com.arches.peerconnect.enums;

public enum Roles {
	MD_DO, DMD, DDS, PharmD_RPh, PA, CRNA_NP_APRN, RN, OTHER;

}

package com.arches.peerconnect.service;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.arches.peerconnect.entity.Captain;
import com.arches.peerconnect.repository.CaptainRepository;

@Service
public class CaptainService {
	
	@Autowired
	private CaptainRepository captainRepository;

	public List<Captain> getAllCaptain() {
		return captainRepository.findAll();
	}

	public Captain saveCaptain(Captain captain) {
		captainRepository.save(captain);
		return captain;
	}
}
